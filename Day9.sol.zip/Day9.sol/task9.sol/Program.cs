﻿using System;

namespace task9.sol
{
    //=============proplem1==============


    //class Program
    //{
    //    enum Weekdays
    //    {
    //        Monday = 1,
    //        Tuesday,
    //        Wednesday,
    //        Thursday,
    //        Friday
    //    }

    //    static void Main(string[] args)
    //    {
    //        foreach (Weekdays day in Enum.GetValues(typeof(Weekdays)))
    //        {
    //            Console.WriteLine($"{day} = {(int)day}");
    //        }
    //    }
    //}







    //=============proplem2==============


    //class Program
    //{
    //    enum Grades : short
    //    {
    //        F = 1,
    //        D,
    //        C,
    //        B,
    //        A
    //    }

    //    static void Main(string[] args)
    //    {
    //        foreach (Grades grade in Enum.GetValues(typeof(Grades)))
    //        {
    //            Console.WriteLine($"{grade} = {(short)grade}");
    //        }
    //    }
    //}





    //=============proplem3==============

    //class Person
    //{
    //    public string Name { get; set; }
    //    public int Age { get; set; }
    //    public string Department { get; set; }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Person p1 = new Person { Name = "Ali", Age = 25, Department = "IT" };
    //        Person p2 = new Person { Name = "Sara", Age = 30, Department = "HR" };

    //        Console.WriteLine($"Name: {p1.Name}, Age: {p1.Age}, Department: {p1.Department}");
    //        Console.WriteLine($"Name: {p2.Name}, Age: {p2.Age}, Department: {p2.Department}");
    //    }
    //}





    //=============proplem4==============

    //class Parent
    //{
    //    public virtual int Salary { get; set; }
    //}

    //class Child : Parent
    //{
    //    public sealed override int Salary { get; set; }

    //    public void DisplaySalary()
    //    {
    //        Console.WriteLine($"Salary: {Salary}");
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Child c = new Child { Salary = 5000 };
    //        c.DisplaySalary();
    //    }
    //}




    //=============proplem5==============


    //static class Utility
    //{
    //    public static int CalculatePerimeter(int length, int width)
    //    {
    //        return 2 * (length + width);
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        int result = Utility.CalculatePerimeter(10, 5);
    //        Console.WriteLine($"Perimeter: {result}");
    //    }
    //}



    //=============proplem6==============


    //class ComplexNumber
    //{
    //    public int Real { get; set; }
    //    public int Imaginary { get; set; }

    //    public ComplexNumber(int real, int imaginary)
    //    {
    //        Real = real;
    //        Imaginary = imaginary;
    //    }

    //    public static ComplexNumber operator *(ComplexNumber c1, ComplexNumber c2)
    //    {
    //        return new ComplexNumber(
    //            c1.Real * c2.Real - c1.Imaginary * c2.Imaginary,
    //            c1.Real * c2.Imaginary + c1.Imaginary * c2.Real
    //        );
    //    }

    //    public override string ToString()
    //    {
    //        return $"{Real} + {Imaginary}i";
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        ComplexNumber c1 = new ComplexNumber(3, 2);
    //        ComplexNumber c2 = new ComplexNumber(1, 7);
    //        ComplexNumber result = c1 * c2;
    //        Console.WriteLine(result);
    //    }
    //}



    //=============proplem7==============

    //enum GenderDefault
    //{
    //    Male,
    //    Female
    //}

    //enum GenderByte : byte
    //{
    //    Male,
    //    Female
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Console.WriteLine($"Size of GenderDefault (int): {sizeof(GenderDefault)} bytes");
    //        Console.WriteLine($"Size of GenderByte (byte): {sizeof(GenderByte)} bytes");
    //    }
    //}



    //=============proplem8==============

    //static class Utility
    //{
    //    public static double CelsiusToFahrenheit(double celsius)
    //    {
    //        return (celsius * 9 / 5) + 32;
    //    }

    //    public static double FahrenheitToCelsius(double fahrenheit)
    //    {
    //        return (fahrenheit - 32) * 5 / 9;
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        double c = 25;
    //        double f = 77;
    //        Console.WriteLine($"{c}C = {Utility.CelsiusToFahrenheit(c)}F");
    //        Console.WriteLine($"{f}F = {Utility.FahrenheitToCelsius(f)}C");
    //    }
    //}



    //=============proplem9==============

    //enum Grades
    //{
    //    F = 1,
    //    D,
    //    C,
    //    B,
    //    A
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        string input = "B";
    //        if (Enum.TryParse(input, out Grades grade))
    //        {
    //            Console.WriteLine($"Parsed value: {grade} = {(int)grade}");
    //        }
    //        else
    //        {
    //            Console.WriteLine("Invalid grade input");
    //        }
    //    }
    //}



    //=============proplem10=============

    //class Employee
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }

    //    public override bool Equals(object obj)
    //    {
    //        if (obj is Employee e)
    //            return Id == e.Id && Name == e.Name;
    //        return false;
    //    }

    //    public override int GetHashCode()
    //    {
    //        return HashCode.Combine(Id, Name);
    //    }

    //    public override string ToString()
    //    {
    //        return $"Id: {Id}, Name: {Name}";
    //    }
    //}

    //class Helper2<T>
    //{
    //    public static int SearchArray(T[] array, T item)
    //    {
    //        for (int i = 0; i < array.Length; i++)
    //        {
    //            if (array[i].Equals(item))
    //                return i;
    //        }
    //        return -1;
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Employee[] employees =
    //        {
    //            new Employee { Id = 1, Name = "Ali" },
    //            new Employee { Id = 2, Name = "Sara" },
    //            new Employee { Id = 3, Name = "Omar" }
    //        };

    //        Employee searchTarget = new Employee { Id = 2, Name = "Sara" };
    //        int index = Helper2<Employee>.SearchArray(employees, searchTarget);
    //        Console.WriteLine(index);
    //    }
    //}



    //=============proplem11=============

    //class Helper
    //{
    //    public static T Max<T>(T a, T b) where T : IComparable<T>
    //    {
    //        return a.CompareTo(b) >= 0 ? a : b;
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Console.WriteLine(Helper.Max(10, 20));
    //        Console.WriteLine(Helper.Max(5.5, 2.3));
    //        Console.WriteLine(Helper.Max("Apple", "Banana"));
    //    }
    //}




    //=============proplem12=============

    //class Helper2<T>
    //{
    //    public static void ReplaceArray(T[] array, T oldValue, T newValue)
    //    {
    //        for (int i = 0; i < array.Length; i++)
    //        {
    //            if (array[i].Equals(oldValue))
    //                array[i] = newValue;
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        int[] numbers = { 1, 2, 3, 2, 4 };
    //        Helper2<int>.ReplaceArray(numbers, 2, 9);
    //        Console.WriteLine(string.Join(", ", numbers));

    //        string[] words = { "apple", "banana", "apple", "cherry" };
    //        Helper2<string>.ReplaceArray(words, "apple", "orange");
    //        Console.WriteLine(string.Join(", ", words));
    //    }
    //}



    //=============proplem13=============

    struct Rectangle
    {
        public int Length { get; set; }
        public int Width { get; set; }

        public override string ToString()
        {
            return $"Length: {Length}, Width: {Width}";
        }
    }

    //class Helper
    //{
    //    public static void Swap(ref Rectangle r1, ref Rectangle r2)
    //    {
    //        Rectangle temp = r1;
    //        r1 = r2;
    //        r2 = temp;
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Rectangle rect1 = new Rectangle { Length = 5, Width = 10 };
    //        Rectangle rect2 = new Rectangle { Length = 15, Width = 20 };

    //        Console.WriteLine("Before Swap:");
    //        Console.WriteLine(rect1);
    //        Console.WriteLine(rect2);

    //        Helper.Swap(ref rect1, ref rect2);

    //        Console.WriteLine("After Swap:");
    //        Console.WriteLine(rect1);
    //        Console.WriteLine(rect2);
    //    }
    //}



    //=============proplem14=============

    //class Department
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }

    //    public override bool Equals(object obj)
    //    {
    //        if (obj is Department d)
    //            return Id == d.Id && Name == d.Name;
    //        return false;
    //    }

    //    public override int GetHashCode()
    //    {
    //        return HashCode.Combine(Id, Name);
    //    }

    //    public override string ToString()
    //    {
    //        return $"Id: {Id}, Name: {Name}";
    //    }
    //}

    //class Employee
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //    public Department Department { get; set; }

    //    public override string ToString()
    //    {
    //        return $"Id: {Id}, Name: {Name}, Department: {Department.Name}";
    //    }
    //}

    //class Helper2<T>
    //{
    //    public static int SearchArray(T[] array, T item)
    //    {
    //        for (int i = 0; i < array.Length; i++)
    //        {
    //            if (array[i].Equals(item))
    //                return i;
    //        }
    //        return -1;
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Department d1 = new Department { Id = 1, Name = "IT" };
    //        Department d2 = new Department { Id = 2, Name = "HR" };

    //        Employee[] employees =
    //        {
    //            new Employee { Id = 1, Name = "Ali", Department = d1 },
    //            new Employee { Id = 2, Name = "Sara", Department = d2 },
    //            new Employee { Id = 3, Name = "Omar", Department = d1 }
    //        };

    //        int index = Helper2<Employee>.SearchArray(employees, new Employee { Id = 2, Name = "Sara", Department = d2 });
    //        Console.WriteLine(index);
    //    }
    //}





    //=============proplem15=============

    //struct CircleStruct
    //{
    //    public double Radius { get; set; }
    //    public string Color { get; set; }

    //    public override bool Equals(object obj)
    //    {
    //        if (obj is CircleStruct c)
    //            return Radius == c.Radius && Color == c.Color;
    //        return false;
    //    }

    //    public override int GetHashCode()
    //    {
    //        return HashCode.Combine(Radius, Color);
    //    }

    //    public static bool operator ==(CircleStruct c1, CircleStruct c2)
    //    {
    //        return c1.Equals(c2);
    //    }

    //    public static bool operator !=(CircleStruct c1, CircleStruct c2)
    //    {
    //        return !c1.Equals(c2);
    //    }

    //    public override string ToString()
    //    {
    //        return $"Radius: {Radius}, Color: {Color}";
    //    }
    //}

    //class CircleClass
    //{
    //    public double Radius { get; set; }
    //    public string Color { get; set; }

    //    public override bool Equals(object obj)
    //    {
    //        if (obj is CircleClass c)
    //            return Radius == c.Radius && Color == c.Color;
    //        return false;
    //    }

    //    public override int GetHashCode()
    //    {
    //        return HashCode.Combine(Radius, Color);
    //    }

    //    public override string ToString()
    //    {
    //        return $"Radius: {Radius}, Color: {Color}";
    //    }
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        CircleStruct cs1 = new CircleStruct { Radius = 5, Color = "Red" };
    //        CircleStruct cs2 = new CircleStruct { Radius = 5, Color = "Red" };

    //        Console.WriteLine("Struct Comparison:");
    //        Console.WriteLine(cs1 == cs2);
    //        Console.WriteLine(cs1.Equals(cs2));

    //        CircleClass cc1 = new CircleClass { Radius = 5, Color = "Red" };
    //        CircleClass cc2 = new CircleClass { Radius = 5, Color = "Red" };

    //        Console.WriteLine("Class Comparison:");
    //        Console.WriteLine(cc1 == cc2);
    //        Console.WriteLine(cc1.Equals(cc2));
    //    }
    //}


    //=============part2==============

    //=============proplem1,2,3,4==============

    //class Helper
    //{
    //    public static T[] ReverseArray<T>(T[] array)
    //    {
    //        T[] result = new T[array.Length];
    //        for (int i = 0; i < array.Length; i++)
    //            result[i] = array[array.Length - 1 - i];
    //        return result;
    //    }

    //    public static void Swap<T>(T[] array, int i, int j)
    //    {
    //        T temp = array[i];
    //        array[i] = array[j];
    //        array[j] = temp;
    //    }

    //    public static T Max<T>(T[] array) where T : IComparable<T>
    //    {
    //        T max = array[0];
    //        for (int i = 1; i < array.Length; i++)
    //            if (array[i].CompareTo(max) > 0)
    //                max = array[i];
    //        return max;
    //    }
    //}

    //class Stack<T>
    //{
    //    private T[] items;
    //    private int count;

    //    public Stack(int capacity)
    //    {
    //        items = new T[capacity];
    //        count = 0;
    //    }

    //    public void Push(T item)
    //    {
    //        items[count++] = item;
    //    }

    //    public T Pop()
    //    {
    //        return items[--count];
    //    }

    //    public T Peek()
    //    {
    //        return items[count - 1];
    //    }

    //    public int Count => count;
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        int[] nums = { 1, 2, 3, 4, 5 };
    //        var reversed = Helper.ReverseArray(nums);
    //        Console.WriteLine(string.Join(", ", reversed));

    //        Stack<string> stack = new Stack<string>(5);
    //        stack.Push("A");
    //        stack.Push("B");
    //        stack.Push("C");
    //        Console.WriteLine(stack.Pop());
    //        Console.WriteLine(stack.Peek());

    //        string[] words = { "one", "two", "three" };
    //        Helper.Swap(words, 0, 2);
    //        Console.WriteLine(string.Join(", ", words));

    //        double[] values = { 3.5, 7.2, 1.8, 9.4 };
    //        Console.WriteLine(Helper.Max(values));
    //    }
    //}






}
