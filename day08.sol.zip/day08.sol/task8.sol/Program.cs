﻿using System;

namespace task8.sol
{
    //=============proplem1==================

    //interface IVehicle
    //{
    //    void StartEngine();
    //    void StopEngine();
    //}

    //class Car : IVehicle
    //{
    //    public void StartEngine() => Console.WriteLine("Car engine started.");
    //    public void StopEngine() => Console.WriteLine("Car engine stopped.");
    //}

    //class Bike : IVehicle
    //{
    //    public void StartEngine() => Console.WriteLine("Bike engine started.");
    //    public void StopEngine() => Console.WriteLine("Bike engine stopped.");
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        IVehicle car = new Car();
    //        IVehicle bike = new Bike();

    //        car.StartEngine();
    //        car.StopEngine();

    //        bike.StartEngine();
    //        bike.StopEngine();
    //    }
    //}







    //=============proplem2==================




    //abstract class Shape
    //{
    //    public abstract double GetArea();
    //    public void Display() => Console.WriteLine($"Area: {GetArea()}");
    //}

    //class Rectangle : Shape
    //{
    //    double width, height;
    //    public Rectangle(double w, double h) { width = w; height = h; }
    //    public override double GetArea() => width * height;
    //}

    //class Circle : Shape
    //{
    //    double radius;
    //    public Circle(double r) { radius = r; }
    //    public override double GetArea() => Math.PI * radius * radius;
    //}

    //interface IShape
    //{
    //    double GetArea();
    //}

    //class RectangleI : IShape
    //{
    //    double width, height;
    //    public RectangleI(double w, double h) { width = w; height = h; }
    //    public double GetArea() => width * height;
    //}

    //class CircleI : IShape
    //{
    //    double radius;
    //    public CircleI(double r) { radius = r; }
    //    public double GetArea() => Math.PI * radius * radius;
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Shape rect = new Rectangle(5, 4);
    //        Shape circle = new Circle(3);

    //        rect.Display();
    //        circle.Display();

    //        IShape rectI = new RectangleI(5, 4);
    //        IShape circleI = new CircleI(3);

    //        Console.WriteLine($"Area: {rectI.GetArea()}");
    //        Console.WriteLine($"Area: {circleI.GetArea()}");
    //    }
    //}















    //=============proplem3==================




    //class Product : IComparable<Product>
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //    public double Price { get; set; }

    //    public Product(int id, string name, double price)
    //    {
    //        Id = id;
    //        Name = name;
    //        Price = price;
    //    }

    //    public int CompareTo(Product other)
    //    {
    //        if (other == null) return 1;
    //        return Price.CompareTo(other.Price);
    //    }

    //    public override string ToString() => $"{Id} - {Name} - {Price}";
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Product[] products =
    //        {
    //            new Product(1, "Laptop", 800),
    //            new Product(2, "Phone", 500),
    //            new Product(3, "Tablet", 300)
    //        };

    //        Array.Sort(products);

    //        foreach (var p in products)
    //            Console.WriteLine(p);
    //    }
    //}







    //=============proplem4==================



    /*  class Student
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public Grade Grade { get; set; }

            public Student(int id, string name, Grade grade)
            {
                Id = id;
                Name = name;
                Grade = grade;
            }

            public Student(Student other)
            {
                Id = other.Id;
                Name = other.Name;
                Grade = new Grade(other.Grade.Score);
            }

            public override string ToString() => $"{Id} - {Name} - {Grade.Score}";
        }

        class Grade
        {
            public int Score { get; set; }
            public Grade(int score) { Score = score; }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Student s1 = new Student(1, "Ali", new Grade(90));
                Student shallow = s1;
                Student deep = new Student(s1);

                s1.Grade.Score = 60;

                Console.WriteLine("Original: " + s1);
                Console.WriteLine("Shallow Copy: " + shallow);
                Console.WriteLine("Deep Copy: " + deep);
            }
        }*/







    //=============proplem5==================


    // interface IWalkable
    //{
    //    void Walk();
    //}

    //class Robot : IWalkable
    //{
    //    public void Walk() => Console.WriteLine("Robot is walking normally.");

    //    void IWalkable.Walk() => Console.WriteLine("Robot walking as IWalkable.");
    //}

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Robot r = new Robot();
    //        r.Walk();

    //        IWalkable w = r;
    //        w.Walk();
    //    }
    //}











    //=============proplem6==================




    /* struct Account
        {
            private int accountId;
            private string accountHolder;
            private double balance;

            public int AccountId { get => accountId; set => accountId = value; }
            public string AccountHolder { get => accountHolder; set => accountHolder = value; }
            public double Balance { get => balance; set => balance = value; }

            public override string ToString() => $"{AccountId} - {AccountHolder} - {Balance}";
        }

        class Program
        {
            static void Main(string[] args)
            {
                Account acc = new Account();
                acc.AccountId = 1;
                acc.AccountHolder = "Omar";
                acc.Balance = 5000;

                Console.WriteLine(acc);
            }
        }*/












    //=============proplem7==================




    /* interface ILogger
        {
            void Log(string message)
            {
                Console.WriteLine($"Default Log: {message}");
            }
        }

        class ConsoleLogger : ILogger
        {
            public void Log(string message)
            {
                Console.WriteLine($"Console Log: {message}");
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                ILogger logger1 = new ConsoleLogger();
                ILogger logger2 = new TestLogger();

                logger1.Log("Hello from ConsoleLogger");
                logger2.Log("Hello from Default Implementation");
            }
        }*/




    //=============proplem8==================




    /*class Book
        {
            public string Title { get; set; }
            public string Author { get; set; }

            public Book()
            {
                Title = "Unknown";
                Author = "Unknown";
            }

            public Book(string title)
            {
                Title = title;
                Author = "Unknown";
            }

            public Book(string title, string author)
            {
                Title = title;
                Author = author;
            }

            public override string ToString() => $"{Title} by {Author}";
        }

        class Program
        {
            static void Main(string[] args)
            {
                Book b1 = new Book();
                Book b2 = new Book("1984");
                Book b3 = new Book("The Hobbit", "J.R.R. Tolkien");

                Console.WriteLine(b1);
                Console.WriteLine(b2);
                Console.WriteLine(b3);
            }
        }*/






    //=============proplem9==================



    //interface IShapeSeries
    //{
    //    int CurrentShapeArea { get; set; }
    //    void GetNextArea();
    //    void ResetSeries();
    //}

    //class SquareSeries : IShapeSeries
    //{
    //    private int side = 1;
    //    public int CurrentShapeArea { get; set; }
    //    public void GetNextArea()
    //    {
    //        CurrentShapeArea = side * side;
    //        side++;
    //    }
    //    public void ResetSeries() { side = 1; CurrentShapeArea = 0; }
    //}

    //class CircleSeries : IShapeSeries
    //{
    //    private int radius = 1;
    //    public int CurrentShapeArea { get; set; }
    //    public void GetNextArea()
    //    {
    //        CurrentShapeArea = (int)(Math.PI * radius * radius);
    //        radius++;
    //    }
    //    public void ResetSeries() { radius = 1; CurrentShapeArea = 0; }
    //}

    //class Shape : IComparable
    //{
    //    public string Name { get; set; }
    //    public double Area { get; set; }
    //    public int CompareTo(object obj)
    //    {
    //        Shape other = (Shape)obj;
    //        return Area.CompareTo(other.Area);
    //    }
    //    public override string ToString() => $"{Name} - {Area:F2}";
    //}

    //abstract class GeometricShape
    //{
    //    public double Dimension1 { get; set; }
    //    public double Dimension2 { get; set; }
    //    public abstract double CalculateArea();
    //    public abstract double Perimeter { get; }
    //}

    //class Triangle : GeometricShape
    //{
    //    public override double CalculateArea() => 0.5 * Dimension1 * Dimension2;
    //    public override double Perimeter => Dimension1 + Dimension2 + Math.Sqrt(Dimension1 * Dimension1 + Dimension2 * Dimension2);
    //}

    //class Rectangle : GeometricShape
    //{
    //    public override double CalculateArea() => Dimension1 * Dimension2;
    //    public override double Perimeter => 2 * (Dimension1 + Dimension2);
    //}

    //static class ShapeFactory
    //{
    //    public static GeometricShape CreateShape(string shapeType, double d1, double d2)
    //    {
    //        switch (shapeType.ToLower())
    //        {
    //            case "rectangle": return new Rectangle { Dimension1 = d1, Dimension2 = d2 };
    //            case "triangle": return new Triangle { Dimension1 = d1, Dimension2 = d2 };
    //            default: return null;
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void PrintTenShapes(IShapeSeries series)
    //    {
    //        series.ResetSeries();
    //        for (int i = 0; i < 10; i++)
    //        {
    //            series.GetNextArea();
    //            Console.WriteLine(series.CurrentShapeArea);
    //        }
    //    }

    //    public static void SelectionSort(int[] numbers)
    //    {
    //        int n = numbers.Length;
    //        for (int i = 0; i < n - 1; i++)
    //        {
    //            int min = i;
    //            for (int j = i + 1; j < n; j++)
    //                if (numbers[j] < numbers[min]) min = j;
    //            int temp = numbers[min];
    //            numbers[min] = numbers[i];
    //            numbers[i] = temp;
    //        }
    //    }

    //    static void Main(string[] args)
    //    {
    //        Console.WriteLine("Square Series:");
    //        PrintTenShapes(new SquareSeries());

    //        Console.WriteLine("\nCircle Series:");
    //        PrintTenShapes(new CircleSeries());

    //        Shape[] shapes =
    //        {
    //            new Shape { Name = "Square", Area = 25 },
    //            new Shape { Name = "Circle", Area = 78.5 },
    //            new Shape { Name = "Rectangle", Area = 40 }
    //        };
    //        Array.Sort(shapes);
    //        Console.WriteLine("\nSorted Shapes by Area:");
    //        foreach (var s in shapes) Console.WriteLine(s);

    //        var rect = ShapeFactory.CreateShape("Rectangle", 5, 10);
    //        var tri = ShapeFactory.CreateShape("Triangle", 6, 8);

    //        Console.WriteLine($"\nRectangle Area: {rect.CalculateArea()}, Perimeter: {rect.Perimeter}");
    //        Console.WriteLine($"Triangle Area: {tri.CalculateArea()}, Perimeter: {tri.Perimeter}");

    //        int[] areas = { 50, 10, 30, 20, 40 };
    //        SelectionSort(areas);
    //        Console.WriteLine("\nAreas after Selection Sort:");
    //        foreach (var a in areas) Console.WriteLine(a);
    //    }
    //}




}
