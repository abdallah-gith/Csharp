﻿using System;

namespace task6.sol
{


    using System;

    //struct Point
    //{
    //    public int X;
    //    public int Y;

    //    public Point(int x, int y)
    //    {
    //        X = x;
    //        Y = y;
    //    }
    //    public Point()
    //    {
    //        X = 0;
    //        Y = 0;
    //    }

    //    public override string ToString() => $"({X}, {Y})";

    //}






    //struct Employee
    //{

    //    private int EmpId;
    //    private string Name;
    //    private decimal Salary;

    //    public Employee(int empId, string name, decimal salary)
    //    {
    //        EmpId = empId;
    //        Name = name;
    //        Salary = salary;
    //    }
    //    public string GetName()
    //    {
    //        return Name;
    //    }

    //    public void SetName(string newName)
    //    {
    //            Name = newName;
    //    }
    //    public int EmployeeId
    //    {
    //        get { return EmpId; }
    //    }
    //    public decimal EmployeeSalary
    //    {
    //        get { return Salary; }
    //        set
    //        {
    //                Salary = value;

    //        }
    //    }

    //    public override string ToString()
    //    {
    //        return $"ID: {EmpId}, Name: {Name}, Salary: {Salary:C}";
    //    }
    //}




    //struct Point
    //{
    //    public int X { get; }
    //    public int Y { get; }

    //    public Point(int x)
    //    {
    //        X = x;
    //        Y = 0;
    //    }

    //    public Point(int x, int y)
    //    {
    //        X = x;
    //        Y = y;
    //    }

    //    public override string ToString()
    //    {
    //        return $"({X}, {Y})";
    //    }
    //}








    //struct Point
    //{
    //    public int X { get; }
    //    public int Y { get; }

    //    public Point(int x, int y)
    //    {
    //        X = x;
    //        Y = y;
    //    }

    //    public override string ToString()
    //    {
    //        return $"Point => X: {X}, Y: {Y}";
    //    }
    //}









    struct Point
    {
        public int X;
        public int Y;
    }

    class Employee
    {
        public string Name;
    }






    class Program
    {

        static void ChangePoint(Point p)
        {
            p.X = 100;
            p.Y = 200;
        }

        static void ChangeEmployee(Employee e)
        {
            e.Name = "Changed Name";
        }


        static void Main()
        {
            //Point p1 = new Point();
            //Point p2 = new Point(3, 5);

            //Console.WriteLine(p1);
            //Console.WriteLine(p2);







            //    TypeA obj = new TypeA();


            //    Console.WriteLine(obj.G);    
            //    Console.WriteLine(obj.H);    

            //    obj.ShowValues();






            //Employee emp = new Employee(101, "Ali", 5000m);
            //Console.WriteLine("Name via GetName(): " + emp.GetName());
            //emp.SetName("Omar");
            //Console.WriteLine("Updated Name: " + emp.GetName());
            //Console.WriteLine("ID: " + emp.EmployeeId);






            //Point p1 = new Point(5);
            //Point p2 = new Point(3, 7);

            //Console.WriteLine(p1); 
            //Console.WriteLine(p2); 






            //Point p1 = new Point(3, 5);
            //Point p2 = new Point(-2, 7);
            //Point p3 = new Point(0, 0);

            //Console.WriteLine(p1);
            //Console.WriteLine(p2);
            //Console.WriteLine(p3);




            Point pt = new Point { X = 1, Y = 2 };
            Employee emp = new Employee { Name = "Ali" };

            ChangePoint(pt);
            ChangeEmployee(emp);

            Console.WriteLine($"Point after method: X={pt.X}, Y={pt.Y}");  
            Console.WriteLine($"Employee after method: Name={emp.Name}");


        }
    }
}







  