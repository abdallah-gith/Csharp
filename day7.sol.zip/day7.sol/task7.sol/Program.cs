﻿using System;
using System.Runtime.ConstrainedExecution;

namespace task7.sol
{




    //class Car
    //{
    //    public int Id { get; set; }
    //    public string Brand { get; set; }
    //    public decimal Price { get; set; }

    //    public Car()
    //    {
    //        Id = 0;
    //        Brand = "Unknown";
    //        Price = 0;
    //        Console.WriteLine("Default constructor called");
    //    }

    //    public Car(int id)
    //    {
    //        Id = id;
    //        Brand = "Unknown";
    //        Price = 0;
    //        Console.WriteLine("Constructor with Id called");
    //    }

    //    public Car(int id, string brand)
    //    {
    //        Id = id;
    //        Brand = brand;
    //        Price = 0;
    //        Console.WriteLine("Constructor with Id and Brand called");
    //    }

    //    public Car(int id, string brand, decimal price)
    //    {
    //        Id = id;
    //        Brand = brand;
    //        Price = price;
    //        Console.WriteLine("Constructor with Id, Brand, and Price called");
    //    }

    //    public void ShowDetails()
    //    {
    //        Console.WriteLine($"Id: {Id}, Brand: {Brand}, Price: {Price}");
    //    }


    //}




    //class Calculator
    //{
    //    public int Sum(int a, int b)
    //    {
    //        return a + b;
    //    }

    //    public int Sum(int a, int b, int c)
    //    {
    //        return a + b + c;
    //    }

    //    public double Sum(double a, double b)
    //    {
    //        return a + b;
    //    }
    //}





    //class Parent
    //{
    //    public int X { get; set; }
    //    public int Y { get; set; }

    //    public Parent(int x, int y)
    //    {
    //        X = x;
    //        Y = y;
    //        Console.WriteLine("Parent constructor called");
    //    }
    //}

    //class Child : Parent
    //{
    //    public int Z { get; set; }

    //    public Child(int x, int y, int z) : base(x, y)
    //    {
    //        Z = z;
    //        Console.WriteLine("Child constructor called");
    //    }

    //    public void print()
    //    {
    //        Console.WriteLine($"X: {X}, Y: {Y}, Z: {Z}");
    //    }
    //}



    //class Parent
    //{
    //    public int X { get; set; }
    //    public int Y { get; set; }

    //    public Parent(int x, int y)
    //    {
    //        X = x;
    //        Y = y;
    //    }

    //    public virtual int Product()
    //    {
    //        return X * Y;
    //    }
    //}

    //class ChildNew : Parent
    //{
    //    public int Z { get; set; }

    //    public ChildNew(int x, int y, int z) : base(x, y)
    //    {
    //        Z = z;
    //    }

    //    public new int Product()
    //    {
    //        return X * Y * Z;
    //    }
    //}

    //class ChildOverride : Parent
    //{
    //    public int Z { get; set; }

    //    public ChildOverride(int x, int y, int z) : base(x, y)
    //    {
    //        Z = z;
    //    }

    //    public override int Product()
    //    {
    //        return X * Y * Z;
    //    }
    //}


    //class Parent
    //{
    //    public int X { get; set; }
    //    public int Y { get; set; }

    //    public Parent(int x, int y)
    //    {
    //        X = x;
    //        Y = y;
    //    }

    //    public override string ToString()
    //    {
    //        return $"({X}, {Y})";
    //    }
    //}

    //class Child : Parent
    //{
    //    public int Z { get; set; }

    //    public Child(int x, int y, int z) : base(x, y)
    //    {
    //        Z = z;
    //    }

    //    public override string ToString()
    //    {
    //        return $"({X}, {Y}, {Z})";
    //    }
    //}




    //interface IShape
    //{
    //    double Area { get; }
    //    void Draw();
    //}

    //class Rectangle : IShape
    //{
    //    public double Width { get; set; }
    //    public double Height { get; set; }

    //    public Rectangle(double width, double height)
    //    {
    //        Width = width;
    //        Height = height;
    //    }

    //    public double Area
    //    {
    //        get { return Width * Height; }
    //    }

    //    public void Draw()
    //    {
    //        Console.WriteLine($"Drawing a rectangle with width={Width}, height={Height}");
    //    }
    //}






    //interface IShape
    //{
    //    double Area { get; }
    //    void Draw();

    //    void PrintDetails()
    //    {
    //        Console.WriteLine($"Shape details: Area = {Area}");
    //    }
    //}

    //class Circle : IShape
    //{
    //    public double Radius { get; set; }

    //    public Circle(double radius)
    //    {
    //        Radius = radius;
    //    }

    //    public double Area
    //    {
    //        get { return Math.PI * Radius * Radius; }
    //    }

    //    public void Draw()
    //    {
    //        Console.WriteLine($"Drawing a circle with radius = {Radius}");
    //    }
    //}



    //interface IMovable
    //{
    //    void Move();
    //}

    //class Car : IMovable
    //{
    //    public void Move()
    //    {
    //        Console.WriteLine("The car is moving...");
    //    }
    //}




    //interface IReadable
    //{
    //    void Read();
    //}

    //interface IWritable
    //{
    //    void Write();
    //}

    //class File : IReadable, IWritable
    //{
    //    public void Read()
    //    {
    //        Console.WriteLine("Reading from file...");
    //    }

    //    public void Write()
    //    {
    //        Console.WriteLine("Writing to file...");
    //    }
    //}







    //abstract class Shape
    //{
    //    public virtual void Draw()
    //    {
    //        Console.WriteLine("Drawing Shape");
    //    }

    //    public abstract double CalculateArea();
    //}

    //class Rectangle : Shape
    //{
    //    public double Width { get; set; }
    //    public double Height { get; set; }

    //    public Rectangle(double width, double height)
    //    {
    //        Width = width;
    //        Height = height;
    //    }

    //    public override void Draw()
    //    {
    //        Console.WriteLine("Drawing Rectangle");
    //    }

    //    public override double CalculateArea()
    //    {
    //        return Width * Height;
    //    }
    //}




    class Program
        {
            static void Main(string[] args)
            {

            //Car car1 = new Car();
            //car1.ShowDetails();

            //Car car2 = new Car(101);
            //car2.ShowDetails();

            //Car car3 = new Car(102, "Toyota");
            //car3.ShowDetails();

            //Car car4 = new Car(103, "BMW", 55000);
            //car4.ShowDetails();








            //Calculator calc = new Calculator();

            //Console.WriteLine("Sum of 2 integers: " + calc.Sum(5, 10));
            //Console.WriteLine("Sum of 3 integers: " + calc.Sum(5, 10, 15));
            //Console.WriteLine("Sum of 2 doubles: " + calc.Sum(5.5, 10.3));





            //Child obj = new Child(10, 20, 30);
            //obj.print();




            //Parent p2 = new ChildOverride(2, 3, 4);
            //Console.WriteLine("Using override: " + p2.Product());

            //ChildNew c1 = new ChildNew(2, 3, 4);
            //Console.WriteLine("ChildNew reference: " + c1.Product());



            //Parent p = new Parent(10, 20);
            //Console.WriteLine("Parent: " + p);

            //Child c = new Child(10, 20, 30);
            //Console.WriteLine("Child: " + c);

            //Parent pc = new Child(5, 6, 7);
            //Console.WriteLine("Polymorphism (Parent ref to Child): " + pc);





            //IShape shape = new Rectangle(5, 10);
            //shape.Draw();
            //Console.WriteLine("Area: " + shape.Area);




            //IShape shape = new Circle(5);
            //shape.Draw();
            //shape.PrintDetails();



            //IMovable movable = new Car();
            //movable.Move();





            //File file = new File();
            //file.Read();
            //file.Write();

            //IReadable readable = file;
            //readable.Read();

            //IWritable writable = file;
            //writable.Write();





            //Shape shape = new Rectangle(5, 10);
            //shape.Draw();
            //Console.WriteLine("Area: " + shape.CalculateArea());



        }
        }
    }

