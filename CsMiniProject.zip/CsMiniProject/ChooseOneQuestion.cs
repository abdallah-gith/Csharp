﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public class ChooseOneQuestion : Question
    {
        public ChooseOneQuestion(string body, int marks)
            : base("Choose One Answer Question", body, marks)
        {
        }

        public override void Display()
        {
            Console.WriteLine($"{Header} ({Marks} Marks)");
            Console.WriteLine(Body);
            foreach (var answer in PossibleAnswers)
            {
                Console.WriteLine(answer);
            }
        }
    }
}
