﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    using System;
    using System.Linq;

    namespace ExaminationSystem
    {
        public class PracticeExam : Exam
        {
            public PracticeExam(TimeSpan time, int numberOfQuestions, Subject subject)
                : base(time, numberOfQuestions, subject)
            {
            }

            // ## Updated to show results ##
            public override void ShowExamResult()
            {
                Console.Clear();
                Console.WriteLine("===== Practice Exam Results =====");
                Console.WriteLine(Subject);
                Console.WriteLine("===============================\n");
                int totalMarks = 0;
                int studentScore = 0;

                foreach (var question in Questions)
                {
                    totalMarks += question.Marks;
                    question.Display();
                    var userAnswers = UserAnswers[question];
                    Console.Write("Your Answer(s): ");
                    Console.WriteLine(string.Join(", ", userAnswers.Select(a => a.Text)));

                    var correctAnswers = question.RightAnswers;
                    Console.Write("Correct Answer(s): ");
                    Console.WriteLine(string.Join(", ", correctAnswers.Select(a => a.Text)));

                    bool isCorrect = userAnswers.Count == correctAnswers.Count &&
                                     userAnswers.All(ua => correctAnswers.Contains(ua));

                    if (isCorrect)
                    {
                        studentScore += question.Marks;
                        Console.WriteLine($"Result: Correct! (+{question.Marks} Marks)\n");
                    }
                    else
                    {
                        Console.WriteLine("Result: Incorrect.\n");
                    }
                    Console.WriteLine("----------------------------------\n");
                }
                Console.WriteLine($"Total Score: {studentScore} / {totalMarks}");
                Console.WriteLine("===== End of Practice Exam =====");
            }
        }
    }
}
