﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public class TrueOrFalseQuestion : Question
    {
        public TrueOrFalseQuestion(string body, int marks)
            : base("True or False Question", body, marks)
        {
            PossibleAnswers.Add(new Answer(1, "True"));
            PossibleAnswers.Add(new Answer(2, "False"));
        }

        public override void Display()
        {
            Console.WriteLine($"{Header} ({Marks} Marks)");
            Console.WriteLine(Body);
            foreach (var answer in PossibleAnswers)
            {
                Console.WriteLine(answer);
            }
        }
    }
}
