﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public abstract class Question
    {
        public string Header { get; set; }
        public string Body { get; set; }
        public int Marks { get; set; }

        public AnswerList PossibleAnswers { get; set; }

        public AnswerList RightAnswers { get; set; }

        public Question()
        {
            PossibleAnswers = new AnswerList();
            RightAnswers = new AnswerList();
        }

        public Question(string header, string body, int marks) : this()
        {
            Header = header;
            Body = body;
            Marks = marks;
        }

        public abstract void Display();

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Header: {Header}");
            sb.AppendLine($"Body: {Body}");
            sb.AppendLine($"Marks: {Marks}");
            return sb.ToString();
        }
    }
}
