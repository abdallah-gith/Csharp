﻿using CsMiniProject.ExaminationSystem;
using System;

namespace CsMiniProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            Subject cSharpSubject = new Subject(101, "C# Programming");
            PracticeExam practiceExam = new PracticeExam(TimeSpan.FromMinutes(30), 2, cSharpSubject);
            FinalExam finalExam = new FinalExam(TimeSpan.FromMinutes(60), 2, cSharpSubject);

            #region Populate Practice Exam Questions
            var q1_practice = new TrueOrFalseQuestion("Is C# a statically-typed language?", 5);
            q1_practice.RightAnswers.Add(q1_practice.PossibleAnswers[0]);
            practiceExam.Questions.Add(q1_practice);

            var q2_practice = new ChooseOneQuestion("Which of the following is a value type in C#?", 5);
            q2_practice.PossibleAnswers.Add(new Answer(1, "String"));
            q2_practice.PossibleAnswers.Add(new Answer(2, "Class"));
            q2_practice.PossibleAnswers.Add(new Answer(3, "Struct"));
            q2_practice.PossibleAnswers.Add(new Answer(4, "Interface"));
            q2_practice.RightAnswers.Add(q2_practice.PossibleAnswers[2]); 
            practiceExam.Questions.Add(q2_practice);
            #endregion

            #region Populate Final Exam Questions
            var q1_final = new ChooseAllQuestion("Which keywords are used for exception handling?", 10);
            q1_final.PossibleAnswers.Add(new Answer(1, "try"));
            q1_final.PossibleAnswers.Add(new Answer(2, "catch"));
            q1_final.PossibleAnswers.Add(new Answer(3, "finally"));
            q1_final.PossibleAnswers.Add(new Answer(4, "throwaway"));
            q1_final.RightAnswers.Add(q1_final.PossibleAnswers[0]);
            q1_final.RightAnswers.Add(q1_final.PossibleAnswers[1]);
            q1_final.RightAnswers.Add(q1_final.PossibleAnswers[2]); 
            finalExam.Questions.Add(q1_final);

            var q2_final = new TrueOrFalseQuestion("Can you create an instance of an abstract class?", 10);
            q2_final.RightAnswers.Add(q2_final.PossibleAnswers[1]);
            finalExam.Questions.Add(q2_final);
            #endregion

           
            Console.WriteLine("Welcome to the Examination System!");
            Console.WriteLine("Please choose the type of exam you want to take:");
            Console.WriteLine("1. Practice Exam");
            Console.WriteLine("2. Final Exam");
            Console.Write("Enter your choice (1 or 2): ");

            string choice = Console.ReadLine();

            if (choice == "1")
            {
               
                practiceExam.TakeExam();
              
                practiceExam.ShowExamResult();
            }
            else if (choice == "2")
            {
               
                finalExam.TakeExam();
                
                finalExam.ShowExamResult();
            }
            else
            {
                Console.WriteLine("Invalid choice. Please run the program again.");
            }

            Console.ReadKey();
        }
    }
}
