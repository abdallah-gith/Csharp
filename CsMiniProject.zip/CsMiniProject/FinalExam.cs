﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public class FinalExam : Exam
    {
        public FinalExam(TimeSpan time, int numberOfQuestions, Subject subject)
            : base(time, numberOfQuestions, subject)
        {
        }


        public override void ShowExamResult()
        {
            Console.Clear();
            Console.WriteLine("======= Final Exam Results =======");
            Console.WriteLine(Subject);
            Console.WriteLine("================================\n");
            int totalMarks = 0;
            int studentScore = 0;

            foreach (var question in Questions)
            {
                totalMarks += question.Marks;
                question.Display();

                var userAnswers = UserAnswers[question];
                Console.Write("Your Chosen Answer(s): ");
                Console.WriteLine(string.Join(", ", userAnswers.Select(a => a.Text)));

                var correctAnswers = question.RightAnswers;
                bool isCorrect = userAnswers.Count == correctAnswers.Count &&
                                 userAnswers.All(ua => correctAnswers.Contains(ua));

                if (isCorrect)
                {
                    studentScore += question.Marks;
                }
                Console.WriteLine("\n----------------------------------\n");
            }

            Console.WriteLine($"Your Final Score is: {studentScore} out of {totalMarks}");
            Console.WriteLine("======== End of Final Exam ========");
        }
    }
}
