﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public class QuestionList : List<Question>
    {
        private readonly string _logFilePath;

        public QuestionList(string logFileName)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            _logFilePath = Path.Combine(desktopPath, logFileName);
        }

        public new void Add(Question question)
        {
            base.Add(question);

            using (StreamWriter writer = new StreamWriter(_logFilePath, append: true))
            {
                writer.WriteLine("================= New Question Logged =================");
                writer.WriteLine($"Log Time: {DateTime.Now}");
                writer.Write(question.ToString()); 
                writer.WriteLine("======================================================");
                writer.WriteLine();
            }
        }
    }
}
