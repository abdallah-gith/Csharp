﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public abstract class Exam : ICloneable, IComparable
    {
        public TimeSpan Time { get; set; }
        public int NumberOfQuestions { get; set; }
        public Subject Subject { get; set; }
        public ExamMode Mode { get; set; }
        public Dictionary<Question, AnswerList> QuestionAnswerDictionary { get; set; }
        public QuestionList Questions { get; set; }

        public Dictionary<Question, AnswerList> UserAnswers { get; set; }

        public Exam(TimeSpan time, int numberOfQuestions, Subject subject)
        {
            Time = time;
            NumberOfQuestions = numberOfQuestions;
            Subject = subject;
            Mode = ExamMode.Queued;
            Questions = new QuestionList($"{this.GetType().Name}_Questions.log");
            QuestionAnswerDictionary = new Dictionary<Question, AnswerList>();

            UserAnswers = new Dictionary<Question, AnswerList>();
        }

        public abstract void ShowExamResult();

        public void TakeExam()
        {
            this.Mode = ExamMode.Starting;
            Console.Clear();
            Console.WriteLine($"Starting {this.GetType().Name} for {Subject.Name}...");

            foreach (var question in Questions)
            {
                question.Display(); 
                Console.WriteLine("----------------------------------");

                AnswerList chosenAnswers = new AnswerList();
                bool isValidAnswer = false;

                while (!isValidAnswer)
                {
                    Console.Write("Enter the number(s) for your answer (e.g., 1 or 1,2): ");
                    string input = Console.ReadLine();

                    var answerIds = input.Split(',');

                    chosenAnswers.Clear(); 

                    foreach (var idStr in answerIds)
                    {
                        if (int.TryParse(idStr.Trim(), out int id))
                        {
                            var selectedAnswer = question.PossibleAnswers.FirstOrDefault(ans => ans.Id == id);
                            if (selectedAnswer != null)
                            {
                                chosenAnswers.Add(selectedAnswer);
                            }
                        }
                    }

                    if (chosenAnswers.Count == answerIds.Length && chosenAnswers.Count > 0)
                    {
                        isValidAnswer = true;
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter a valid answer number.");
                    }
                }

                UserAnswers.Add(question, chosenAnswers);
                Console.WriteLine("\n==================================\n");
            }
            this.Mode = ExamMode.Finished;
        }

        #region Interface Implementations and Overrides
        public object Clone() => this.MemberwiseClone();
        public int CompareTo(object obj)
        {
            if (obj is Exam otherExam) return this.NumberOfQuestions.CompareTo(otherExam.NumberOfQuestions);
            throw new ArgumentException("Object is not an Exam");
        }
        public override string ToString() => $"Exam for Subject: {Subject.Name}, Duration: {Time}, Questions: {NumberOfQuestions}";
        public override bool Equals(object obj)
        {
            if (obj is Exam other) return (Time == other.Time) && (NumberOfQuestions == other.NumberOfQuestions) && (Subject.Id == other.Subject.Id);
            return false;
        }
        public override int GetHashCode() => HashCode.Combine(Time, NumberOfQuestions, Subject.Id);
        #endregion
    }
}
