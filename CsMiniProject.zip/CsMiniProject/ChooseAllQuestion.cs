﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public class ChooseAllQuestion : Question
    {
        public ChooseAllQuestion(string body, int marks)
            : base("Choose All Correct Answers Question", body, marks)
        {
        }

        public override void Display()
        {
            Console.WriteLine($"{Header} ({Marks} Marks)");
            Console.WriteLine(Body);
            foreach (var answer in PossibleAnswers)
            {
                Console.WriteLine(answer);
            }
        }
    }
}
