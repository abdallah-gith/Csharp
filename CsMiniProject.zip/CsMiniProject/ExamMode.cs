﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsMiniProject
{
    public enum ExamMode
    {
        Starting,
        Queued,
        Finished
    }
}
