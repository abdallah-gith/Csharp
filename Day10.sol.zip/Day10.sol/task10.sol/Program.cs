﻿using System;

namespace task10.sol
{
    //===============proplem1================


    //public class Employee : IComparable<Employee>
    //{
    //    public string Name { get; set; }
    //    public decimal Salary { get; set; }

    //    public int CompareTo(Employee other)
    //    {
    //        return Salary.CompareTo(other.Salary);
    //    }
    //}

    //public class SortingAlgorithm<T> where T : IComparable<T>
    //{
    //    public void Sort(T[] array)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (array[i].CompareTo(array[j]) > 0)
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        Employee[] employees =
    //        {
    //        new Employee { Name = "Alice", Salary = 5000 },
    //        new Employee { Name = "Bob", Salary = 3000 },
    //        new Employee { Name = "Charlie", Salary = 7000 }
    //    };

    //        var sorter = new SortingAlgorithm<Employee>();
    //        sorter.Sort(employees);

    //        foreach (var e in employees)
    //        {
    //            Console.WriteLine($"{e.Name} - {e.Salary}");
    //        }
    //    }
    //}






    //===============proplem2================


    //public class SortingTwo<T>
    //{
    //    public void Sort(T[] array, Func<T, T, int> comparer)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (comparer(array[i], array[j]) > 0)
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int[] numbers = { 5, 2, 9, 1, 7 };

    //        var sorter = new SortingTwo<int>();
    //        sorter.Sort(numbers, (a, b) => b.CompareTo(a));

    //        foreach (var n in numbers)
    //        {
    //            Console.WriteLine(n);
    //        }
    //    }
    //}





    //===============proplem3================


    //public class SortingTwo<T>
    //{
    //    public void Sort(T[] array, Func<T, T, int> comparer)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (comparer(array[i], array[j]) > 0)
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        string[] words = { "apple", "dog", "banana", "cat", "grapefruit" };

    //        var sorter = new SortingTwo<string>();
    //        sorter.Sort(words, (a, b) => a.Length.CompareTo(b.Length));

    //        foreach (var word in words)
    //        {
    //            Console.WriteLine(word);
    //        }
    //    }
    //}





    //===============proplem4================


    //public class Employee
    //{
    //    public string Name { get; set; }
    //    public decimal Salary { get; set; }
    //}

    //public class Manager : Employee, IComparable<Manager>
    //{
    //    public int CompareTo(Manager other)
    //    {
    //        return Salary.CompareTo(other.Salary);
    //    }
    //}

    //public class SortingAlgorithm<T> where T : IComparable<T>
    //{
    //    public void Sort(T[] array)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (array[i].CompareTo(array[j]) > 0)
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        Manager[] managers =
    //        {
    //        new Manager { Name = "Alice", Salary = 9000 },
    //        new Manager { Name = "Bob", Salary = 5000 },
    //        new Manager { Name = "Charlie", Salary = 12000 }
    //    };

    //        var sorter = new SortingAlgorithm<Manager>();
    //        sorter.Sort(managers);

    //        foreach (var m in managers)
    //        {
    //            Console.WriteLine($"{m.Name} - {m.Salary}");
    //        }
    //    }
    //}






    //===============proplem5================


    //public class Employee
    //{
    //    public string Name { get; set; }
    //    public decimal Salary { get; set; }
    //}

    //public class SortingDelegate<T>
    //{
    //    public void Sort(T[] array, Func<T, T, bool> comparer)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (comparer(array[i], array[j]))
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        Employee[] employees =
    //        {
    //        new Employee { Name = "Alice", Salary = 5000 },
    //        new Employee { Name = "Bob", Salary = 7000 },
    //        new Employee { Name = "Charlie", Salary = 6000 }
    //    };

    //        var sorter = new SortingDelegate<Employee>();
    //        sorter.Sort(employees, (a, b) => a.Name.Length > b.Name.Length);

    //        foreach (var e in employees)
    //        {
    //            Console.WriteLine($"{e.Name} - {e.Salary}");
    //        }
    //    }
    //}





    //===============proplem6================


    //public class SortingTwo<T>
    //{
    //    public void Sort(T[] array, Func<T, T, int> comparer)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (comparer(array[i], array[j]) > 0)
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int[] numbers1 = { 9, 2, 5, 1, 7 };
    //        int[] numbers2 = { 9, 2, 5, 1, 7 };

    //        var sorter = new SortingTwo<int>();

    //        sorter.Sort(numbers1, delegate (int a, int b) { return a.CompareTo(b); });
    //        sorter.Sort(numbers2, (a, b) => a.CompareTo(b));

    //        Console.WriteLine("Anonymous Function:");
    //        foreach (var n in numbers1) Console.WriteLine(n);

    //        Console.WriteLine("Lambda Expression:");
    //        foreach (var n in numbers2) Console.WriteLine(n);
    //    }
    //}





    //===============proplem7================


    //public class SortingAlgorithm<T> where T : IComparable<T>
    //{
    //    public void Sort(T[] array)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (array[i].CompareTo(array[j]) > 0)
    //                {
    //                    Swap(ref array[i], ref array[j]);
    //                }
    //            }
    //        }
    //    }

    //    public static void Swap<TItem>(ref TItem a, ref TItem b)
    //    {
    //        TItem temp = a;
    //        a = b;
    //        b = temp;
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int[] numbers = { 10, 20, 30, 40 };

    //        Console.WriteLine("Before Swap: " + string.Join(", ", numbers));
    //        SortingAlgorithm<int>.Swap(ref numbers[0], ref numbers[3]);
    //        Console.WriteLine("After Swap: " + string.Join(", ", numbers));
    //    }
    //}






    //===============proplem8================


    //public class Employee
    //{
    //    public string Name { get; set; }
    //    public decimal Salary { get; set; }
    //}

    //public class SortingTwo<T>
    //{
    //    public void Sort(T[] array, Func<T, T, int> comparer)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (comparer(array[i], array[j]) > 0)
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        Employee[] employees =
    //        {
    //        new Employee { Name = "Alice", Salary = 5000 },
    //        new Employee { Name = "Bob", Salary = 7000 },
    //        new Employee { Name = "Charlie", Salary = 5000 },
    //        new Employee { Name = "David", Salary = 7000 }
    //    };

    //        var sorter = new SortingTwo<Employee>();
    //        sorter.Sort(employees, (a, b) =>
    //        {
    //            int salaryCompare = a.Salary.CompareTo(b.Salary);
    //            return salaryCompare != 0 ? salaryCompare : a.Name.CompareTo(b.Name);
    //        });

    //        foreach (var e in employees)
    //        {
    //            Console.WriteLine($"{e.Name} - {e.Salary}");
    //        }
    //    }
    //}






    //===============proplem9================


    //public class Utility
    //{
    //    public static T GetDefault<T>()
    //    {
    //        return default(T);
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int defaultInt = Utility.GetDefault<int>();
    //        string defaultString = Utility.GetDefault<string>();
    //        bool defaultBool = Utility.GetDefault<bool>();
    //        DateTime defaultDate = Utility.GetDefault<DateTime>();
    //        object defaultObject = Utility.GetDefault<object>();

    //        Console.WriteLine($"Default int: {defaultInt}");
    //        Console.WriteLine($"Default string: {defaultString ?? "null"}");
    //        Console.WriteLine($"Default bool: {defaultBool}");
    //        Console.WriteLine($"Default DateTime: {defaultDate}");
    //        Console.WriteLine($"Default object: {defaultObject ?? "null"}");
    //    }
    //}





    //===============proplem10===============


    //public class Employee : ICloneable, IComparable<Employee>
    //{
    //    public string Name { get; set; }
    //    public decimal Salary { get; set; }

    //    public object Clone()
    //    {
    //        return new Employee { Name = this.Name, Salary = this.Salary };
    //    }

    //    public int CompareTo(Employee other)
    //    {
    //        return Salary.CompareTo(other.Salary);
    //    }
    //}

    //public class SortingAlgorithm<T> where T : ICloneable, IComparable<T>
    //{
    //    public T[] CloneArray(T[] array)
    //    {
    //        T[] cloned = new T[array.Length];
    //        for (int i = 0; i < array.Length; i++)
    //        {
    //            cloned[i] = (T)array[i].Clone();
    //        }
    //        return cloned;
    //    }

    //    public void Sort(T[] array)
    //    {
    //        for (int i = 0; i < array.Length - 1; i++)
    //        {
    //            for (int j = i + 1; j < array.Length; j++)
    //            {
    //                if (array[i].CompareTo(array[j]) > 0)
    //                {
    //                    T temp = array[i];
    //                    array[i] = array[j];
    //                    array[j] = temp;
    //                }
    //            }
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        Employee[] employees =
    //        {
    //        new Employee { Name = "Alice", Salary = 6000 },
    //        new Employee { Name = "Bob", Salary = 4000 },
    //        new Employee { Name = "Charlie", Salary = 8000 }
    //    };

    //        var sorter = new SortingAlgorithm<Employee>();
    //        Employee[] clonedEmployees = sorter.CloneArray(employees);
    //        sorter.Sort(clonedEmployees);

    //        Console.WriteLine("Original:");
    //        foreach (var e in employees)
    //            Console.WriteLine($"{e.Name} - {e.Salary}");

    //        Console.WriteLine("Cloned & Sorted:");
    //        foreach (var e in clonedEmployees)
    //            Console.WriteLine($"{e.Name} - {e.Salary}");
    //    }
    //}






    //===============proplem11===============



    //public delegate string StringTransformer(string input);

    //public class Transformer
    //{
    //    public static string[] ApplyTransformation(string[] items, StringTransformer transformer)
    //    {
    //        string[] result = new string[items.Length];
    //        for (int i = 0; i < items.Length; i++)
    //        {
    //            result[i] = transformer(items[i]);
    //        }
    //        return result;
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        string[] words = { "apple", "banana", "cherry" };

    //        string[] uppercased = Transformer.ApplyTransformation(words, s => s.ToUpper());
    //        string[] reversed = Transformer.ApplyTransformation(words, s =>
    //        {
    //            char[] arr = s.ToCharArray();
    //            Array.Reverse(arr);
    //            return new string(arr);
    //        });
    //        string[] withPrefix = Transformer.ApplyTransformation(words, s => "X_" + s);

    //        Console.WriteLine("Uppercase:");
    //        foreach (var word in uppercased) Console.WriteLine(word);

    //        Console.WriteLine("Reversed:");
    //        foreach (var word in reversed) Console.WriteLine(word);

    //        Console.WriteLine("With Prefix:");
    //        foreach (var word in withPrefix) Console.WriteLine(word);
    //    }
    //}






    //===============proplem12===============


    //public delegate int IntOperation(int a, int b);

    //public class Calculator
    //{
    //    public static int Execute(int x, int y, IntOperation operation)
    //    {
    //        return operation(x, y);
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        IntOperation add = (a, b) => a + b;
    //        IntOperation subtract = (a, b) => a - b;
    //        IntOperation multiply = (a, b) => a * b;
    //        IntOperation divide = (a, b) => a / b;

    //        Console.WriteLine("Addition: " + Calculator.Execute(10, 5, add));
    //        Console.WriteLine("Subtraction: " + Calculator.Execute(10, 5, subtract));
    //        Console.WriteLine("Multiplication: " + Calculator.Execute(10, 5, multiply));
    //        Console.WriteLine("Division: " + Calculator.Execute(10, 5, divide));
    //    }
    //}





    //===============proplem13===============



    //public delegate R Transformer<T, R>(T input);

    //public class ArrayTransformer
    //{
    //    public static R[] Transform<T, R>(T[] items, Transformer<T, R> transformer)
    //    {
    //        R[] result = new R[items.Length];
    //        for (int i = 0; i < items.Length; i++)
    //        {
    //            result[i] = transformer(items[i]);
    //        }
    //        return result;
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int[] numbers = { 1, 2, 3, 4, 5 };
    //        string[] words = { "apple", "banana", "cherry" };

    //        string[] numberStrings = ArrayTransformer.Transform(numbers, n => n.ToString());
    //        int[] lengths = ArrayTransformer.Transform(words, w => w.Length);
    //        int[] doubled = ArrayTransformer.Transform(numbers, n => n * 2);

    //        Console.WriteLine("Integers to Strings:");
    //        foreach (var item in numberStrings) Console.WriteLine(item);

    //        Console.WriteLine("String Lengths:");
    //        foreach (var item in lengths) Console.WriteLine(item);

    //        Console.WriteLine("Integers Doubled:");
    //        foreach (var item in doubled) Console.WriteLine(item);
    //    }
    //}





    //===============proplem14===============



    //public class Transformer
    //{
    //    public static TResult[] Apply<T, TResult>(T[] items, Func<T, TResult> transformer)
    //    {
    //        TResult[] result = new TResult[items.Length];
    //        for (int i = 0; i < items.Length; i++)
    //        {
    //            result[i] = transformer(items[i]);
    //        }
    //        return result;
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int[] numbers = { 1, 2, 3, 4, 5 };
    //        Func<int, int> square = x => x * x;

    //        var squaredNumbers = Transformer.Apply(numbers, square);

    //        Console.WriteLine("Squared Numbers:");
    //        foreach (var num in squaredNumbers)
    //        {
    //            Console.WriteLine(num);
    //        }
    //    }
    //}





    //===============proplem15===============



    //public class StringProcessor
    //{
    //    public static void ApplyAction(string[] items, Action<string> action)
    //    {
    //        foreach (var item in items)
    //        {
    //            action(item);
    //        }
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        string[] words = { "apple", "banana", "cherry" };
    //        Action<string> print = s => Console.WriteLine(s);

    //        Console.WriteLine("Printing words:");
    //        StringProcessor.ApplyAction(words, print);
    //    }
    //}





    //===============proplem16===============



    //public class NumberFilter
    //{
    //    public static T[] Filter<T>(T[] items, Predicate<T> predicate)
    //    {
    //        T[] temp = new T[items.Length];
    //        int count = 0;
    //        foreach (var item in items)
    //        {
    //            if (predicate(item))
    //            {
    //                temp[count++] = item;
    //            }
    //        }
    //        T[] result = new T[count];
    //        Array.Copy(temp, result, count);
    //        return result;
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    //        Predicate<int> isEven = n => n % 2 == 0;

    //        int[] evenNumbers = NumberFilter.Filter(numbers, isEven);

    //        Console.WriteLine("Even Numbers:");
    //        foreach (var num in evenNumbers)
    //        {
    //            Console.WriteLine(num);
    //        }
    //    }
    //}





    //===============proplem17===============


    //public class StringFilter
    //{
    //    public static string[] Filter(string[] items, Predicate<string> condition)
    //    {
    //        string[] temp = new string[items.Length];
    //        int count = 0;

    //        foreach (var item in items)
    //        {
    //            if (condition(item))
    //            {
    //                temp[count++] = item;
    //            }
    //        }

    //        string[] result = new string[count];
    //        Array.Copy(temp, result, count);
    //        return result;
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        string[] words = { "apple", "banana", "avocado", "grape", "apricot" };

    //        string[] startsWithA = StringFilter.Filter(words, delegate (string s) { return s.StartsWith("a"); });
    //        string[] containsAn = StringFilter.Filter(words, delegate (string s) { return s.Contains("an"); });

    //        Console.WriteLine("Starts with 'a':");
    //        foreach (var word in startsWithA)
    //        {
    //            Console.WriteLine(word);
    //        }

    //        Console.WriteLine("Contains 'an':");
    //        foreach (var word in containsAn)
    //        {
    //            Console.WriteLine(word);
    //        }
    //    }
    //}




    //===============proplem18===============


    //public class MathOperations
    //{
    //    public static int Execute(int a, int b, Func<int, int, int> operation)
    //    {
    //        return operation(a, b);
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        int add = MathOperations.Execute(10, 5, delegate (int x, int y) { return x + y; });
    //        int subtract = MathOperations.Execute(10, 5, delegate (int x, int y) { return x - y; });
    //        int multiply = MathOperations.Execute(10, 5, delegate (int x, int y) { return x * y; });

    //        Console.WriteLine("Addition: " + add);
    //        Console.WriteLine("Subtraction: " + subtract);
    //        Console.WriteLine("Multiplication: " + multiply);
    //    }
    //}





    //===============proplem19===============



    //public class StringFilter
    //{
    //    public static string[] Filter(string[] items, Predicate<string> condition)
    //    {
    //        string[] temp = new string[items.Length];
    //        int count = 0;

    //        foreach (var item in items)
    //        {
    //            if (condition(item))
    //            {
    //                temp[count++] = item;
    //            }
    //        }

    //        string[] result = new string[count];
    //        Array.Copy(temp, result, count);
    //        return result;
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        string[] words = { "car", "tree", "pen", "elephant", "dog", "bee" };

    //        string[] lengthGreaterThan3 = StringFilter.Filter(words, s => s.Length > 3);
    //        string[] containsE = StringFilter.Filter(words, s => s.Contains('e'));

    //        Console.WriteLine("Strings with length > 3:");
    //        foreach (var word in lengthGreaterThan3)
    //        {
    //            Console.WriteLine(word);
    //        }

    //        Console.WriteLine("Strings containing 'e':");
    //        foreach (var word in containsE)
    //        {
    //            Console.WriteLine(word);
    //        }
    //    }
    //}





    //===============proplem20===============


    //public class MathOperations
    //{
    //    public static double Execute(double a, double b, Func<double, double, double> operation)
    //    {
    //        return operation(a, b);
    //    }
    //}

    //class Program
    //{
    //    static void Main()
    //    {
    //        double division = MathOperations.Execute(10.0, 2.0, (x, y) => x / y);
    //        double exponentiation = MathOperations.Execute(2.0, 3.0, (x, y) => Math.Pow(x, y));

    //        Console.WriteLine("Division: " + division);
    //        Console.WriteLine("Exponentiation: " + exponentiation);
    //    }
    //}





}
