﻿using System;
using System.Collections.Generic;

namespace task5.sol
{
    internal class Program
    {
        //static void PrintMessage(string message, int repeatCount =5)
        //{
        //    for (int i = 0; i < repeatCount; i++)
        //    {
        //        Console.WriteLine(message);
        //    }
        //}



        //static void SumAndMultiply(int x, int y, out int sum, out int product)
        //{
        //    sum = x + y;
        //    product = x * y;
        //}





        //static int SumArray(params int[] numbers)
        //{
        //    int sum = 0;
        //    foreach (int num in numbers)
        //    {
        //        sum += num;
        //    }
        //    return sum;
        //}

        static void Main(string[] args)
        {
            //try
            //{
            //    Console.Write("Enter first integer: ");
            //    int num1 = int.Parse(Console.ReadLine());

            //    Console.Write("Enter second integer: ");
            //    int num2 = int.Parse(Console.ReadLine());

            //    int result = num1 / num2;
            //    Console.WriteLine($"Result: {result}");
            //}
            //catch (DivideByZeroException)
            //{
            //    Console.WriteLine("Error: Cannot divide by zero.");
            //}
            //finally
            //{
            //    Console.WriteLine("Operation complete");
            //}



            //int x, y;

            //while (true)
            //{
            //    Console.Write("Enter a positive integer for X: ");
            //    if (int.TryParse(Console.ReadLine(), out x) && x > 0)
            //        break;
            //    Console.WriteLine("Invalid input. Please enter a positive integer.");
            //}

            //while (true)
            //{
            //    Console.Write("Enter a positive integer for Y (greater than 1): ");
            //    if (int.TryParse(Console.ReadLine(), out y) && y > 1)
            //        break;
            //    Console.WriteLine("Invalid input. Please enter an integer greater than 1.");
            //}

            //Console.WriteLine($"You entered: X = {x}, Y = {y}");






            //int? number = null;


            //int result = number ?? 100;
            //Console.WriteLine($"Result: {result}");


            //if (number.HasValue)
            //{
            //    Console.WriteLine($"Number has value: {number.Value}");
            //}
            //else
            //{
            //    Console.WriteLine("Number is null .");

            //}



            //int[] numbers = new int[5] { 10, 20, 30, 40, 50 };

            //try
            //{ 
            //    Console.WriteLine(numbers[7]);
            //}
            //catch (IndexOutOfRangeException ex)
            //{ 
            //    Console.WriteLine( ex.Message);
            //}




            //int[,] matrix = new int[3, 3];


            //Console.WriteLine("Enter array numbers:");
            //for (int i = 0; i < matrix.GetLength(0); i++) // rows
            //{
            //    for (int j = 0; j < matrix.GetLength(1); j++) // columns
            //    {
            //        Console.Write($"Element [{i},{j}]: ");
            //        matrix[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}

            //Console.WriteLine("\nSum of each row:");
            //for (int i = 0; i < matrix.GetLength(0); i++)
            //{
            //    int rowSum = 0;
            //    for (int j = 0; j < matrix.GetLength(1); j++)
            //    {
            //        rowSum += matrix[i, j];
            //    }
            //    Console.WriteLine($"Row {i + 1}: {rowSum}");
            //}

            //Console.WriteLine("\nSum of each column:");
            //for (int j = 0; j < matrix.GetLength(1); j++)
            //{
            //    int colSum = 0;
            //    for (int i = 0; i < matrix.GetLength(0); i++)
            //    {
            //        colSum += matrix[i, j];
            //    }
            //    Console.WriteLine($"Column {j + 1}: {colSum}");
            //}





            //int[][] jaggedArray = new int[3][];
            //jaggedArray[0] = new int[2]; 
            //jaggedArray[1] = new int[4]; 
            //jaggedArray[2] = new int[3]; 


            //for (int i = 0; i < jaggedArray.Length; i++)
            //{
            //    Console.WriteLine($"Enter {jaggedArray[i].Length} values for row {i + 1}:");
            //    for (int j = 0; j < jaggedArray[i].Length; j++)
            //    {
            //        Console.Write($"Element [{i}][{j}]: ");
            //        jaggedArray[i][j] = int.Parse(Console.ReadLine());
            //    }
            //}

            //Console.WriteLine("\nJagged array:");
            //for (int i = 0; i < jaggedArray.Length; i++)
            //{

            //    for (int j = 0; j < jaggedArray[i].Length; j++)
            //    {
            //        Console.Write(jaggedArray[i][j] + " ");
            //    }
            //    Console.WriteLine();
            //}






            //string? name = null; 

            //Console.Write("Do you want to enter your name? (y/n): ");
            //string choice = Console.ReadLine() ?? "";

            //if (choice.ToLower() == "y")
            //{
            //    Console.Write("Enter your name: ");
            //    name = Console.ReadLine();
            //}

            //Console.WriteLine("Hello, " + name!);

            //    try{

            //    int num = 2;
            //    object boxedNum = num;
            //    Console.WriteLine($"Boxed: {boxedNum}");

            //    int unboxedNum = (int)boxedNum;
            //    Console.WriteLine($"Unboxed: {unboxedNum}");

            //}
            //catch (InvalidCastException ex)
            //{
            //        Console.WriteLine($"Error: {ex.Message}");
            //    }




            //int a = 5, b = 3;
            //int sum, product;

            //SumAndMultiply(a, b, out sum, out product);

            //Console.WriteLine($"Sum: {sum}");
            //Console.WriteLine($"Product: {product}");








            //PrintMessage("Hello");
            //PrintMessage("Hi", 3);
            //PrintMessage(message: "Named Parameter Example", repeatCount: 2);
            //PrintMessage(repeatCount: 4, message: "Order Changed");





            //int[]? numbers = null; 

            //Console.WriteLine("Length: " + numbers?.Length); 










            //Console.Write("Enter a day of the week capitalize the first letter: ");
            //string day = Console.ReadLine() ?? "";

            //int dayNumber = day switch
            //{
            //    "Monday" => 1,
            //    "Tuesday" => 2,
            //    "Wednesday" => 3,
            //    "Thursday" => 4,
            //    "Friday" => 5,
            //    "Saturday" => 6,
            //    "Sunday" => 7,
            //    "" => 0 
            //};

            //if (dayNumber > 0)
            //    Console.WriteLine($"The number for {day} is {dayNumber}.");
            //else
            //    Console.WriteLine("Invalid day entered.");









            //int sum1 = SumArray(1, 2, 3, 4, 5);
            //Console.WriteLine($"Sum :   {sum1}");










            //===================Part02===========================



            //Console.Write("Enter a positive integer: ");
            //int number = int.Parse(Console.ReadLine());



            //    for (int i = 1; i <= number; i++)
            //    {
            //        Console.Write(i);
            //        if (i < number)
            //            Console.Write(" ");
            //    }






            //Console.Write("Enter an integer: ");
            //int number = int.Parse(Console.ReadLine());

            //for (int i = 1; i <= 12; i++)
            //{
            //    Console.Write(number * i);
            //        Console.Write(" ");
            //}





            //Console.Write("Enter a number: ");
            //int num = int.Parse(Console.ReadLine());

            //for (int i = 2; i <= num; i += 2)
            //{
            //    Console.Write(i);

            //        Console.Write(" ");
            //}






            //Console.Write("Enter the base number: ");
            //int baseNum = int.Parse(Console.ReadLine());

            //Console.Write("Enter the exponent: ");
            //int exponent = int.Parse(Console.ReadLine());

            //int result = 1;

            //for (int i = 0; i < exponent; i++)
            //{
            //    result *= baseNum;
            //}

            //Console.WriteLine($"{baseNum}^{exponent} = {result}");





            //Console.Write("Enter a string: ");
            //string input = Console.ReadLine();

            //string reversed = "";
            //for (int i = input.Length - 1; i >= 0; i--)
            //{
            //    reversed += input[i];
            //}

            //Console.WriteLine("Reversed string: " + reversed);






            //Console.Write("Enter an integer: ");
            //int number = int.Parse(Console.ReadLine());

            //int reversed = 0;

            //while (number != 0)
            //{
            //    int digit = number % 10;     
            //    reversed = reversed * 10 + digit; 
            //    number /= 10;                 
            //}

            //Console.WriteLine("Reversed integer: " + reversed);






            //Console.Write("Enter the number of elements in the array: ");
            //int n = int.Parse(Console.ReadLine());

            //int[] arr = new int[n];
            //Console.WriteLine("Enter the array elements:");
            //for (int i = 0; i < n; i++)
            //{
            //    arr[i] = int.Parse(Console.ReadLine());
            //}

            //int maxDistance = -1;
            //int numWithMaxDistance = -1;

            //for (int i = 0; i < n; i++)
            //{
            //    for (int j = i + 1; j < n; j++)
            //    {
            //        if (arr[i] == arr[j])
            //        {
            //            int distance = j - i - 1; 
            //            if (distance > maxDistance)
            //            {
            //                maxDistance = distance;
            //                numWithMaxDistance = arr[i];
            //            }
            //        }
            //    }
            //}

            //if (maxDistance >= 0)
            //{
            //    Console.WriteLine($"The longest distance is between two '{numWithMaxDistance}' elements, distance: {maxDistance} cells.");
            //}
            //else
            //{
            //    Console.WriteLine("No matching elements found.");
            //}





            //Console.Write("Enter a sentence: ");
            //string sentence = Console.ReadLine();

            //string[] words = sentence.Split(' ');
            //Array.Reverse(words);

            //Console.WriteLine(string.Join(" ", words));

        }
    
    }
}